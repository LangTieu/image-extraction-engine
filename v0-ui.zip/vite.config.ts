import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import { mockApi } from './dev/mock-api.ts'

// Production: `vite build` emits static files in dist/ that the FastAPI app serves at /.
// The UI only ever calls relative /v1 paths (see src/api.ts).
//
// Development only:
//   API_PROXY_TARGET=http://localhost:8000 pnpm dev   -> /v1 is proxied to the real backend
//   pnpm dev                                          -> /v1 is answered by dev/mock-api.ts
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const proxyTarget = env.API_PROXY_TARGET

  return {
    plugins: [react(), ...(proxyTarget ? [] : [mockApi()])],
    server: {
      host: true,
      port: 3000,
      strictPort: true,
      // The v0 preview reaches the dev server through this hostname.
      allowedHosts: ['image-extraction-ui-aabbcc2aa35a6f91.v0.build'],
      proxy: proxyTarget ? { '/v1': { target: proxyTarget, changeOrigin: true } } : undefined,
    },
  }
})
