// DEVELOPMENT ONLY. An in-memory stand-in for the Image Extraction Engine API so the UI can be
// exercised with `pnpm dev` when no backend is running. It implements exactly the endpoints the
// UI calls and nothing else, and it is never part of `vite build`.
//
// The JSON shapes here are this mock's guess at the real schema; the real contract is the
// backend's OpenAPI document. Files whose name contains "fail" are reported as failed.

import { randomUUID } from 'node:crypto'
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Plugin } from 'vite'

const PAGE = { width: 1000, height: 1300 }
const CHAR_WIDTH = 12
const QUEUED_MS = 3_000
const PROCESSING_MS = 12_000

interface MockField {
  field_id: string
  name: string
  value: string
  original_value: string
  confidence: number
  needs_review: boolean
  review_status: string | null
  bbox: [number, number, number, number]
  alternatives: { value: string; confidence: number }[]
  reasons: string[]
  row?: number
  col?: number
}

interface MockFile {
  file_id: string
  filename: string
  error: string | null
  fields: MockField[]
  cells: MockField[]
}

interface MockJob {
  job_id: string
  createdAt: number
  profile: string
  files: MockFile[]
  cancelled: boolean
  exports: Set<string>
}

interface Flag {
  confidence: number
  reasons: string[]
  alternatives: [string, number][]
}

type Spec = [name: string, value: string, x: number, y: number, flag?: Flag]

const HEADERS = ['Description', 'Qty', 'Unit price', 'Amount']
const COLUMN_X = [60, 560, 660, 820]
const ROW_Y = (row: number) => 520 + row * 44

const FIELD_SPECS: Spec[] = [
  ['Vendor name', 'Northwind Paper Supply GmbH', 280, 170],
  [
    'Invoice number',
    'INV-2O26-0412',
    280,
    210,
    { confidence: 0.58, reasons: ['low_confidence', 'pattern_mismatch'], alternatives: [['INV-2026-0412', 0.71], ['INV-2Q26-0412', 0.12]] },
  ],
  ['Invoice date', '2026-11-18', 280, 250],
  ['Due date', '2026-12-l8', 280, 290, { confidence: 0.49, reasons: ['invalid_date'], alternatives: [['2026-12-18', 0.83]] }],
  ['Customer', 'Harbor and Finch Ltd.', 280, 330],
  ['IBAN', 'DE89 3704 0044 0532 0130 00', 280, 370],
  ['Subtotal', '587.80', 820, 730],
  ['Tax', '111.68', 820, 770],
  [
    'Total',
    '699.4B',
    820,
    810,
    { confidence: 0.62, reasons: ['Total does not match subtotal + tax'], alternatives: [['699.48', 0.9], ['699.43', 0.05]] },
  ],
]

const TABLE_ROWS: (string | [string, Flag])[][] = [
  ['A4 copy paper, 80 g, 500 sheets', '40', '4.25', '170.00'],
  [
    'Kraft envelopes C5, box of 250',
    '12',
    '18.90',
    ['226.8O', { confidence: 0.55, reasons: ['low_confidence'], alternatives: [['226.80', 0.88]] }],
  ],
  [
    'Thermal labels 100x150',
    '8',
    ['2l.50', { confidence: 0.47, reasons: ['low_confidence', 'not_a_number'], alternatives: [['21.50', 0.8], ['27.50', 0.1]] }],
    '172.00',
  ],
  ['Delivery', '1', '19.00', '19.00'],
]

const LABELS: [string, number, number][] = [
  ['Vendor', 60, 170],
  ['Invoice no.', 60, 210],
  ['Invoice date', 60, 250],
  ['Due date', 60, 290],
  ['Bill to', 60, 330],
  ['IBAN', 60, 370],
  ['Subtotal', 660, 730],
  ['Tax 19%', 660, 770],
  ['Total', 660, 810],
]

function makeField(name: string, value: string, x: number, y: number, flag: Flag | undefined, reviewed: boolean): MockField {
  const pending = flag !== undefined && !reviewed
  return {
    field_id: `fld_${randomUUID().slice(0, 8)}`,
    name,
    value,
    original_value: value,
    confidence: flag?.confidence ?? 0.93 + Math.round(Math.random() * 6) / 100,
    needs_review: pending,
    review_status: flag !== undefined && reviewed ? 'accepted' : null,
    bbox: [x - 5, y - 20, x + value.length * CHAR_WIDTH + 5, y + 8],
    alternatives: (flag?.alternatives ?? []).map(([v, confidence]) => ({ value: v, confidence })),
    reasons: flag?.reasons ?? [],
  }
}

function makeFile(filename: string, reviewed = false): MockFile {
  const file: MockFile = { file_id: `file_${randomUUID().slice(0, 8)}`, filename, error: null, fields: [], cells: [] }
  if (/fail/i.test(filename)) {
    file.error = 'Unsupported or corrupt image: the file could not be decoded.'
    return file
  }
  file.fields = FIELD_SPECS.map(([name, value, x, y, flag]) => makeField(name, value, x, y, flag, reviewed))
  TABLE_ROWS.forEach((row, r) => {
    row.forEach((entry, c) => {
      const [value, flag] = typeof entry === 'string' ? [entry, undefined] : entry
      const cell = makeField(`${HEADERS[c]}, row ${r + 1}`, value, COLUMN_X[c], ROW_Y(r), flag, reviewed)
      cell.row = r
      cell.col = c
      file.cells.push(cell)
    })
  })
  return file
}

const escapeXml = (value: string) => value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')

/** Draws the scanned "document" the mock boxes refer to, using the values as originally read. */
function documentImage(file: MockFile): string {
  const mono = (value: string, x: number, y: number) =>
    `<text x="${x}" y="${y}" font-family="monospace" font-size="20" textLength="${value.length * CHAR_WIDTH}" lengthAdjust="spacingAndGlyphs" fill="#1c2026">${escapeXml(value)}</text>`
  const label = (value: string, x: number, y: number) =>
    `<text x="${x}" y="${y}" font-family="sans-serif" font-size="15" fill="#6b7280">${escapeXml(value)}</text>`
  const parts = [
    `<svg xmlns="http://www.w3.org/2000/svg" width="${PAGE.width}" height="${PAGE.height}" viewBox="0 0 ${PAGE.width} ${PAGE.height}">`,
    `<rect width="100%" height="100%" fill="#fffdf8"/>`,
    `<text x="60" y="100" font-family="sans-serif" font-size="40" font-weight="700" fill="#1c2026">INVOICE</text>`,
    `<line x1="60" y1="125" x2="940" y2="125" stroke="#1c2026" stroke-width="2"/>`,
    ...LABELS.map(([value, x, y]) => label(value, x, y)),
    ...HEADERS.map((value, c) => label(value, COLUMN_X[c], 470)),
    `<line x1="60" y1="485" x2="940" y2="485" stroke="#9ca3af"/>`,
    `<line x1="60" y1="${ROW_Y(TABLE_ROWS.length) - 20}" x2="940" y2="${ROW_Y(TABLE_ROWS.length) - 20}" stroke="#9ca3af"/>`,
    ...[...file.fields, ...file.cells].map((f) => mono(f.original_value, f.bbox[0] + 5, f.bbox[1] + 20)),
    label(`Scanned file: ${file.filename}`, 60, 1240),
    `</svg>`,
  ]
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(parts.join(''))}`
}

/* ------------------------------------------------------------------ */
/* State                                                               */
/* ------------------------------------------------------------------ */

const jobs: MockJob[] = []

function seed(): void {
  const hour = 3_600_000
  jobs.push(
    {
      job_id: randomUUID(),
      createdAt: Date.now() - 20 * 60_000,
      profile: 'invoices',
      files: [makeFile('invoice-0412.png'), makeFile('receipt-scan-failed.jpg'), makeFile('invoice-0413.png')],
      cancelled: false,
      exports: new Set(['json']),
    },
    {
      job_id: randomUUID(),
      createdAt: Date.now() - 3 * hour,
      profile: 'default',
      files: [makeFile('delivery-note.png', true)],
      cancelled: false,
      exports: new Set(['json', 'csv']),
    },
    {
      job_id: randomUUID(),
      createdAt: Date.now() - 26 * hour,
      profile: 'default',
      files: [makeFile('fax-page-failed.tiff')],
      cancelled: false,
      exports: new Set(),
    },
  )
}

const allFields = (file: MockFile) => [...file.fields, ...file.cells]
const pendingFields = (file: MockFile) => allFields(file).filter((f) => f.needs_review)

function jobState(job: MockJob): { status: string; progress: number; error: string | null } {
  if (job.cancelled) return { status: 'failed', progress: 0, error: 'Cancelled by user.' }
  const elapsed = Date.now() - job.createdAt
  if (elapsed < QUEUED_MS) return { status: 'queued', progress: 0, error: null }
  if (elapsed < QUEUED_MS + PROCESSING_MS) {
    return { status: 'processing', progress: (elapsed - QUEUED_MS) / PROCESSING_MS, error: null }
  }
  if (job.files.every((f) => f.error !== null)) return { status: 'failed', progress: 1, error: 'No file could be processed.' }
  const pending = job.files.some((f) => pendingFields(f).length > 0)
  return { status: pending ? 'needs_review' : 'completed', progress: 1, error: null }
}

function fileStatus(job: MockJob, index: number): string {
  const { status, progress } = jobState(job)
  const file = job.files[index]
  if (status === 'queued') return 'queued'
  const reached = status !== 'processing' || progress >= (index + 1) / job.files.length
  if (!reached) return progress >= index / job.files.length ? 'processing' : 'queued'
  if (file.error !== null) return 'failed'
  return pendingFields(file).length > 0 ? 'needs_review' : 'completed'
}

function jobJson(job: MockJob) {
  const state = jobState(job)
  return {
    job_id: job.job_id,
    status: state.status,
    progress: Math.round(state.progress * 100) / 100,
    profile: job.profile,
    created_at: new Date(job.createdAt).toISOString(),
    updated_at: new Date(Math.min(Date.now(), job.createdAt + QUEUED_MS + PROCESSING_MS)).toISOString(),
    error: state.error,
    files: job.files.map((file, index) => {
      const status = fileStatus(job, index)
      return { file_id: file.file_id, filename: file.filename, status, error: status === 'failed' ? file.error : null }
    }),
  }
}

function fieldJson(field: MockField) {
  const { original_value, ...rest } = field
  return rest.review_status === 'corrected' ? { ...rest, original_value } : rest
}

function resultJson(job: MockJob) {
  return {
    job_id: job.job_id,
    status: jobState(job).status,
    files: job.files.map((file) => ({
      file_id: file.file_id,
      filename: file.filename,
      status: file.error !== null ? 'failed' : 'completed',
      error: file.error,
      category: file.error !== null ? null : 'invoice',
      ...(file.error !== null
        ? {}
        : { image_url: documentImage(file), width: PAGE.width, height: PAGE.height }),
      fields: file.fields.map(fieldJson),
      tables:
        file.cells.length === 0
          ? []
          : [{ table_id: `${file.file_id}_items`, name: 'Line items', headers: HEADERS, cells: file.cells.map(fieldJson) }],
    })),
  }
}

/* ------------------------------------------------------------------ */
/* HTTP plumbing                                                       */
/* ------------------------------------------------------------------ */

function send(res: ServerResponse, status: number, body: unknown, headers: Record<string, string> = {}): void {
  const payload = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body)
  res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...headers })
  res.end(payload)
}

function readBody(req: IncomingMessage): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    req.on('data', (chunk: Buffer) => chunks.push(chunk))
    req.on('end', () => resolve(Buffer.concat(chunks)))
    req.on('error', reject)
  })
}

function parseJson(body: Buffer): Record<string, unknown> | null {
  try {
    const parsed: unknown = JSON.parse(body.toString('utf8'))
    return typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed) ? (parsed as Record<string, unknown>) : null
  } catch {
    return null
  }
}

function parseMultipart(body: Buffer, contentType: string): { filenames: string[]; values: Record<string, string[]> } {
  const boundary = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType)
  const filenames: string[] = []
  const values: Record<string, string[]> = {}
  if (!boundary) return { filenames, values }
  const utf8 = (latin1: string) => Buffer.from(latin1, 'latin1').toString('utf8')
  for (const part of body.toString('latin1').split(`--${boundary[1] ?? boundary[2]}`)) {
    const split = part.indexOf('\r\n\r\n')
    if (split === -1) continue
    const head = part.slice(0, split)
    const name = /name="([^"]*)"/i.exec(head)?.[1]
    if (!name) continue
    const filename = /filename="([^"]*)"/i.exec(head)?.[1]
    if (filename !== undefined) filenames.push(utf8(filename))
    else (values[name] ??= []).push(utf8(part.slice(split + 4).replace(/\r\n$/, '')))
  }
  return { filenames, values }
}

const notFound = (res: ServerResponse, detail: string) => send(res, 404, { detail })

function csvExport(job: MockJob): string {
  const quote = (value: string | number) => `"${String(value).replace(/"/g, '""')}"`
  const rows = [['file', 'field', 'value', 'confidence', 'review_status'].map(quote).join(',')]
  for (const file of job.files) {
    for (const f of allFields(file)) {
      rows.push([file.filename, f.name, f.value, f.confidence, f.review_status ?? ''].map(quote).join(','))
    }
  }
  return rows.join('\r\n')
}

async function handle(req: IncomingMessage, res: ServerResponse, path: string): Promise<void> {
  const method = req.method ?? 'GET'

  if (path === '/health' && method === 'GET') return send(res, 200, { status: 'ok' })
  if (path === '/version' && method === 'GET') return send(res, 200, { version: '7.0.0-devmock' })
  if (path === '/profiles' && method === 'GET') {
    return send(res, 200, [
      { id: 'default', name: 'General documents', description: 'Balanced speed and accuracy for mixed uploads.', default: true, categories: ['invoice', 'receipt', 'form', 'id_card'], languages: ['en'] },
      { id: 'invoices', name: 'Invoices and receipts', description: 'Totals, tax lines and line-item tables.', categories: ['invoice', 'receipt'], languages: ['en', 'de'] },
      { id: 'tables', name: 'Dense tables', description: 'Slower, tuned for large grids.', categories: ['form'], languages: ['en'] },
    ])
  }

  if (path === '/jobs' && method === 'GET') {
    return send(res, 200, [...jobs].sort((a, b) => b.createdAt - a.createdAt).map(jobJson))
  }

  if (path === '/jobs' && method === 'POST') {
    const { filenames, values } = parseMultipart(await readBody(req), req.headers['content-type'] ?? '')
    if (filenames.length === 0) {
      return send(res, 422, { detail: [{ loc: ['body', 'files'], msg: 'Field required', type: 'missing' }] })
    }
    const job: MockJob = {
      job_id: randomUUID(),
      createdAt: Date.now(),
      profile: values.profile?.[0] ?? 'default',
      files: filenames.map((name) => makeFile(name)),
      cancelled: false,
      exports: new Set(values.export_formats ?? []),
    }
    jobs.push(job)
    return send(res, 202, jobJson(job))
  }

  const match = /^\/jobs\/([^/]+)(?:\/(.+))?$/.exec(path)
  if (!match) return notFound(res, 'Not Found')
  const job = jobs.find((j) => j.job_id === decodeURIComponent(match[1]))
  if (!job) return notFound(res, 'Job not found')
  const rest = match[2] ?? ''
  const status = jobState(job).status
  const running = status === 'queued' || status === 'processing'

  if (rest === '' && method === 'GET') return send(res, 200, jobJson(job))

  if (rest === 'cancel' && method === 'POST') {
    if (!running) return send(res, 409, { detail: `Job is already ${status} and cannot be cancelled.` })
    job.cancelled = true
    return send(res, 200, jobJson(job))
  }

  if (rest === 'result' && method === 'GET') {
    if (running) return send(res, 409, { detail: 'Job is not finished yet.' })
    return send(res, 200, resultJson(job))
  }

  if (rest === 'review' && method === 'GET') {
    if (running) return send(res, 409, { detail: 'Job is not finished yet.' })
    return send(res, 200, {
      job_id: job.job_id,
      items: job.files.flatMap((file) => pendingFields(file).map((f) => ({ file_id: file.file_id, ...fieldJson(f) }))),
    })
  }

  const fieldMatch = /^fields\/([^/]+)$/.exec(rest)
  if (fieldMatch && method === 'PATCH') {
    const fieldId = decodeURIComponent(fieldMatch[1])
    const field = job.files.flatMap(allFields).find((f) => f.field_id === fieldId)
    if (!field) return notFound(res, `Field ${fieldId} not found in this job.`)
    const body = parseJson(await readBody(req))
    const action = body?.action
    if (action !== 'accept' && action !== 'correct' && action !== 'reject') {
      return send(res, 422, { detail: [{ loc: ['body', 'action'], msg: "Input should be 'accept', 'correct' or 'reject'" }] })
    }
    if (action === 'correct') {
      if (typeof body?.value !== 'string') {
        return send(res, 422, { detail: [{ loc: ['body', 'value'], msg: 'Field required when action is correct' }] })
      }
      field.value = body.value
    }
    field.needs_review = false
    field.review_status = action === 'accept' ? 'accepted' : action === 'correct' ? 'corrected' : 'rejected'
    return send(res, 200, fieldJson(field))
  }

  if (rest === 'exports' && method === 'POST') {
    const formats = parseJson(await readBody(req))?.formats
    const valid = ['xlsx', 'json', 'csv', 'pdf']
    if (!Array.isArray(formats) || formats.length === 0 || formats.some((f) => !valid.includes(String(f)))) {
      return send(res, 422, { detail: [{ loc: ['body', 'formats'], msg: 'Expected a list of xlsx, json, csv or pdf' }] })
    }
    if (running) return send(res, 409, { detail: 'Job is not finished yet.' })
    for (const fmt of formats) job.exports.add(String(fmt))
    return send(res, 202, { job_id: job.job_id, formats, status: 'accepted' })
  }

  const exportMatch = /^exports\/([^/]+)$/.exec(rest)
  if (exportMatch && method === 'GET') {
    const fmt = exportMatch[1]
    if (!['xlsx', 'json', 'csv', 'pdf'].includes(fmt)) return notFound(res, `Unknown export format "${fmt}".`)
    if (!job.exports.has(fmt)) return notFound(res, `The ${fmt.toUpperCase()} export has not been generated for this job.`)
    const filename = `job-${job.job_id.slice(0, 8)}.${fmt}`
    const disposition = { 'Content-Disposition': `attachment; filename="${filename}"` }
    if (fmt === 'json') return send(res, 200, JSON.stringify(resultJson(job), null, 2), disposition)
    if (fmt === 'csv') return send(res, 200, csvExport(job), { ...disposition, 'Content-Type': 'text/csv; charset=utf-8' })
    return send(res, 501, { detail: `The development mock cannot build ${fmt.toUpperCase()} files. Run against the real backend.` })
  }

  return send(res, 405, { detail: 'Method Not Allowed' })
}

export function mockApi(): Plugin {
  return {
    name: 'image-extraction-mock-api',
    apply: 'serve',
    configureServer(server) {
      seed()
      server.config.logger.info('  Mock API active at /v1 (set API_PROXY_TARGET to use a real backend)')
      server.middlewares.use((req, res, next) => {
        const url = new URL(req.url ?? '/', 'http://localhost')
        if (url.pathname !== '/v1' && !url.pathname.startsWith('/v1/')) return next()
        handle(req, res, url.pathname.slice(3).replace(/\/$/, '')).catch((error: unknown) => {
          send(res, 500, { detail: error instanceof Error ? error.message : 'Mock API error' })
        })
      })
    },
  }
}
